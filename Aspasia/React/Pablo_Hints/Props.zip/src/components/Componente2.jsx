const Componente2 = ({ result }) => {
    return (
        <p>Resultado: {result}</p>
    )
}

export default Componente2