import React from 'react';

const Componente1: React.FC = () => {
  return <div>Hola Món</div>;
};

export default Componente1;
