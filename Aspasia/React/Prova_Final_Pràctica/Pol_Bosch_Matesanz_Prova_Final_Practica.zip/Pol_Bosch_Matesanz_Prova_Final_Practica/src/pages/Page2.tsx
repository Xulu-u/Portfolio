
const Page2 = () => {

    
    return(
        <div>    
                This is Page2
        </div>
    )
        
}

export default Page2;